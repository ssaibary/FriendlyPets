<?php

class ChatView extends View {
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function show($matches)
    {
        include "../private/chat.php";     
    }
    
}

