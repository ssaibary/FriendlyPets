<?php

class NewPasswordView extends View {
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function show($errors = []) {
        include "../private/resetPassword.php";
    }
    
}

