<?php

class MatchView extends View {
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function show($matches)
    {
        include "../private/match.php";
       
    }
    
}

