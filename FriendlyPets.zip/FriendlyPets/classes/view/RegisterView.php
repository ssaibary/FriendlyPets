<?php

class RegisterView extends View {
    
    public function __construct() {
        parent::__construct();
    }
    
    public function show($errors = [], $data = []) {
        
        // Datos del usuario
        $name = $data['name'] ?? '';
        $email = $data['email'] ?? '';
        $birthday = $data['birthday'] ?? '';
        $gender = $data['gender'] ?? '';
        $password = $data['password'] ?? '';
        $password2 = $data['password2'] ?? '';
        
        // Dirección
        $address = $data['address'] ?? '';
        $cp = $data['cp'] ?? '';
        $poblacio = $data['poblacio'] ?? '';
        $provincia = $data['provincia'] ?? '';
        $number = $data['number'] ?? '';
        
        // Información del perro
        $dog_name = $data['dog-name'] ?? '';
        $dog_birthday = $data['dog-birthday'] ?? '';
        $dog_gender = $data['dog-gender'] ?? '';
        
        // Otros datos
        $agree = $data['agree'] ?? false;
        
        include "../private/register.php";
    }
    
}

