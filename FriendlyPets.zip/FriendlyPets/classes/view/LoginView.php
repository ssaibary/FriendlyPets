<?php

class LoginView extends View
{

    public function __construct()
    {
        parent::__construct();
    }

    public function show($errors = [], $data = [])
    {
        // include $this->file;
        $email = $data['email'] ?? '';

        include "../private/login.php";
    }
}

