<?php

class LegalView extends View {
    
    public function show() {
        include "../private/legal.php";
    }
    
}

