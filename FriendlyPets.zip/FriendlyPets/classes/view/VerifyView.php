<?php

class VerifyView extends View
{

    public function __construct()
    {
        parent::__construct();
    }

    public function show($errors = [])
    {
        // Si existe el mensaje de la sesión, lo mostramos
        $message = isset($_SESSION['message']) ? $_SESSION['message'] : 'No se ha recibido ningún mensaje.';
        
        // Limpiamos el mensaje después de mostrarlo
        unset($_SESSION['message']);
        
        echo "<!DOCTYPE html>
            <html lang=\"es\">
            <head>
                <meta charset=\"UTF-8\">
                <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
                <title>Verificación de Cuenta - Friendly Pets</title>
                <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap\">
                <style>
                    body {
                        font-family: \"Poppins\", sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        background-color: #f7f9fc;
                        margin: 0;
                    }
                    .container {
                        background: white;
                        padding: 2rem;
                        border-radius: 10px;
                        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
                        text-align: center;
                        max-width: 400px;
                    }
                    h1 {
                        color: #ff9100;
                    }
                    p {
                        color: #555;
                    }
                    .success-icon {
                        font-size: 50px;
                        color: #4CAF50;
                    }
                    .error-icon {
                        font-size: 50px;
                        color: #E53935;
                    }
                    .btn {
                        display: inline-block;
                        margin-top: 15px;
                        padding: 10px 20px;
                        background: #ff9100;
                        color: white;
                        text-decoration: none;
                        border-radius: 5px;
                        transition: 0.3s;
                    }
                    .btn:hover {
                        background: #43A047;
                    }
                </style>
            </head>
            <body>
                <div class=\"container\">
                    <div class=\"success-icon\">✔️</div>
                    <h1>¡Cuenta Verificada!</h1>
                    <p>{$message}</p>
            <a href=\"?Login/show\" class=\"btn\">Iniciar sesión</a>
    </body>
    </html>";
    }
    
}


