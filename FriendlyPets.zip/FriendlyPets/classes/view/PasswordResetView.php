<?php

class PasswordResetView extends View {
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function show($errors = [], $data = [])
    {
        $email = $data['email'] ?? '';
        include "../private/sendEmail.php";
    }
    
}

