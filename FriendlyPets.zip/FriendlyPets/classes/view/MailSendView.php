<?php

class MailSendView {
    
    public function show($email){
        echo "<h1>Correo enviado correctamente a {$email}</h1>";
    }
    
}

