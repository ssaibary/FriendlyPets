<?php

class ChatModel {
    
    public function getMatches($userId) {
        $db = DataBase::getInstance();
        $sql = "
        SELECT u.id, u.name, u.dog_name
        FROM users u
        JOIN matches m1 ON m1.user_id = ? AND m1.target_user_id = u.id AND m1.action = 'yes'
        JOIN matches m2 ON m2.user_id = u.id AND m2.target_user_id = ? AND m2.action = 'yes'
        WHERE u.id != ? 
    ";
        
        return $db->executarSQL($sql, [$userId, $userId, $userId]) ?? [];
    }
   
    
    public function getMessages($userId, $matchedUserId) {
        $db = DataBase::getInstance();
        $sql = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?)
                OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC";
        return $db->executarSQL($sql, [$userId, $matchedUserId, $matchedUserId, $userId]) ?? [];
    }
    
    public function sendMessage($senderId, $receiverId, $message) {
        $db = DataBase::getInstance();
        $sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
        $db->executarSQL($sql, [$senderId, $receiverId, $message]);
    }
    
}

