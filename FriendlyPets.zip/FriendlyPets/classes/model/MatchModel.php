<?php

class MatchModel
{

    function __construct()
    {}

    public function getProfiles()
    {
        $db = DataBase::getInstance();
        $userId = $_SESSION['user_id'];

        $sql = "
        SELECT id, name, dog_name, dog_birthday, dog_gender, dog_pictures
        FROM users
        WHERE verified = 1
        AND id NOT IN (
            SELECT id FROM users WHERE id = ?
        )
    ";

        return $db->executarSQL($sql, [
            $userId,
        ]) ?? [];
    }

    public function recordAction($userId, $matchedUserId, $action)
    {
        $db = DataBase::getInstance();
        
        // Insertar acción con control de duplicados
        $sql = "INSERT INTO matches (user_id, target_user_id, action)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE action = VALUES(action)";
        $db->executarSQL($sql, [$userId, $matchedUserId, $action]);
        
        // Solo si el usuario dio like, verificamos si hay match mutuo
        if ($action === "yes") {
            $checkSql = "SELECT 1 FROM matches WHERE user_id = ? AND target_user_id = ? AND action = 'yes'";
            $match = $db->executarSQL($checkSql, [$matchedUserId, $userId]);
            return !empty($match);
        }
        
        return false;
    }
    
}

// public function getProfiles()
// {
//     $db = DataBase::getInstance();
//     $userId = $_SESSION['user_id'];
    
//     $sql = "
//         SELECT id, name, dog_name, dog_birthday, dog_gender, dog_pictures
//         FROM users
//         WHERE verified = 1
//         AND id NOT IN (
//             SELECT target_user_id FROM matches WHERE user_id = ?
//         )
//     ";
    
//     return $db->executarSQL($sql, [
//         $userId,
//     ]) ?? [];
// }