<?php
require __DIR__ . '../../../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class User
{

    protected $id;

    public $name;

    public $email;

    private $password;

    public $birthday;

    public $gender;

    public $address;

    public $cp;

    public $poblacio;

    public $provincia;

    public $number;

    public $dog_name;

    public $dog_birthday;

    public $dog_gender;

    public $dog_pictures = [];

    public $agree;

    public $created_at;

    public $updated_at;

    public $errors;

    function __construct()
    {}
    
    public function register(User $toCreate)
    {
//         echo "Iniciando el proceso de registro...<br>";
        // Obtener la instancia de la conexión a la base de datos
        $db = DataBase::getInstance();

        // Generar un token
        $token = bin2hex(random_bytes(32));
//         echo "Token generado: $token<br>";

        // Convertir el array de rutas de las imágenes en una cadena JSON
        $dogPicturesJson = json_encode($toCreate->dog_pictures);
//         echo "Fotos del perro convertidas a JSON.<br>";

        $sSql = "INSERT INTO users
        (name, email, password, birthday, gender, address, cp, poblacio, provincia, number,
        dog_name, dog_birthday, dog_gender, dog_pictures, agree, verification_token, verified, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW());";

        // Hash de la contraseña
        $passwordHash = password_hash($toCreate->password, PASSWORD_DEFAULT);

        // Parámetros a insertar
        $sParam = array(
            $toCreate->name,
            $toCreate->email,
            $passwordHash,
            $toCreate->birthday,
            $toCreate->gender,
            $toCreate->address,
            $toCreate->cp,
            $toCreate->poblacio,
            $toCreate->provincia,
            $toCreate->number,
            $toCreate->dog_name,
            $toCreate->dog_birthday,
            $toCreate->dog_gender,
            $dogPicturesJson,
            $toCreate->agree,
            $token,
            0
        );

        // Ejecutar la sentencia SQL
        if ($db->executarSQL($sSql, $sParam)) {
            $userID = $db->getLink()->insert_id; // Obtener el ID del registro insertado
//             echo "Llamando a la función de enviar correo...<br>";
            try {
//                 echo "Intentando enviar correo...<br>";
                $this->sendVerificationEmail($toCreate->email, $token);
//                 echo "Correo enviado exitosamente.<br>";
            } catch (Exception $e) {
                echo "Excepción al enviar correo: " . $e->getMessage() . "<br>";
            }

            return $userID;
        } else {
            throw new Exception("Error en la consulta a la base de datos: " . $db->getLink()->getLastError());
        }
    }

    public function login($email, $password)
    {
        $db = DataBase::getInstance();

        $sSql = "SELECT id, name, email, password FROM users WHERE email = ?";
        $sParam = array(
            $email
        );

        // Obtener los resultados
        $result = $db->executarSQL($sSql, $sParam);

        // Verificar si $result contiene un array de datos
        if ($result && is_array($result) && count($result) > 0) {
            $user = $result[0]; // Obtener el primer usuario

            if (! $user['verified']) {
                return "Cuenta no verificada. Por favor revisa tu correo.";
            }

            // Verificar la contraseña
            if (password_verify($password, $user['password'])) {
                return $user; // Contraseña correcta, devolver el usuario
            } else {
                return null; // Contraseña incorrecta
            }
        } else {
            return null; // Usuario no encontrado
        }
    }

    private function sendVerificationEmail($email, $token)
    {
        $mail = new PHPMailer(true);
        try {
            // Configurar el servidor SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Cambia esto
            $mail->SMTPAuth = true;
            $mail->Username = 'sohaib@friendly-pets.net'; // Cambia esto
            $mail->Password = 'unil euio frvw yiza'; // Cambia esto
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

//             $mail->SMTPDebug = 2;
//             $mail->Debugoutput = 'html';

            // Configurar el correo
            $mail->setFrom('sohaib@friendly-pets.net', 'FriendlyPets');
            $mail->addAddress($email);
            $mail->Subject = 'Verifica tu cuenta en FriendlyPets';
            $mail->isHTML(true);

            // Enlace de verificación
            $verificationLink = "http://192.168.103.5/FriendlyPets/public/?Verify/show&token=$token";

            $mail->Body = "
            <h2>¡Bienvenido a FriendlyPets!</h2>
            <p>Gracias por registrarte. Para verificar tu cuenta, haz clic en el siguiente enlace:</p>
            <p><a href='$verificationLink'>Verificar mi cuenta</a></p>
            <p>Si no creaste esta cuenta, puedes ignorar este mensaje.</p>
        ";

            // Enviar el correo
            if ($mail->send()) {
//                 echo "Correo enviado correctamente a $email";
                   $view = new MailSendView();
                   $view->show($email);
            } else {
                echo "Error al enviar correo: " . $mail->ErrorInfo;
            }
        } catch (Exception $e) {
            error_log("Error enviando correo: " . $mail->ErrorInfo);
        }
    }
    

    public function verifyUserToken($token)
    {
        // Usar el método de ejecución de consultas de tu clase de base de datos
        $db = DataBase::getInstance();

        // Consulta para verificar si el token existe y no ha expirado
        $sSql = "SELECT * FROM users WHERE verification_token = ?";
        $sParam = array(
            $token
        );

        $user = $db->executarSQL($sSql, $sParam); // Ejecutar la consulta

        if ($user && is_array($user) && count($user) > 0) {
            // Si el token es válido, actualizar el usuario como verificado
            $updateSql = "UPDATE users SET verified = 1 WHERE verification_token = ?";
            $updateParams = array(
                $token
            );
            $db->executarSQL($updateSql, $updateParams); // Ejecutar la actualización
            return true;
        }

        return false; // Si no se encuentra el usuario o el token ha expirado
    }

    public function getUserByEmail($email)
    {
        $db = DataBase::getInstance();
        $sSql = "SELECT id, name, email, password, verified FROM users WHERE email = ?";
        $sParam = array(
            $email
        );

        $result = $db->executarSQL($sSql, $sParam);

        if ($result && is_array($result) && count($result) > 0) {
            return $result[0]; // Retorna el primer usuario encontrado
        } else {
            return null; // Usuario no encontrado
        }
    }
    
    
    public function sendPasswordReset($email) {
        $user = $this->getUserByEmail($email);
        
        if ($user) {
            // Generar un token único (esto se puede guardar en la base de datos para validaciones futuras)
            $token = bin2hex(random_bytes(50)); // Genera un token seguro de 100 caracteres
            
            // Guarda el token en la base de datos
            $this->storePasswordResetToken($email, $token);
            
            // Crear el enlace de restablecimiento
            $resetLink = "http://192.168.103.5/FriendlyPets/public/?NewPassword/show&token=$token"; // El enlace lleva el token
            
            // Configuración de PHPMailer para enviar el correo
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Servidor SMTP de Gmail
                $mail->SMTPAuth = true;
                $mail->Username = 'sohaib@friendly-pets.net'; // Cambiar a tu cuenta
                $mail->Password = 'unil euio frvw yiza'; // Cambiar a tu clave
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                
                $mail->setFrom('sohaib@friendly-pets.net', 'FriendlyPets');
                $mail->addAddress($email);
                $mail->Subject = 'Restablecimiento de contraseña en FriendlyPets';
                $mail->isHTML(true);
                
                $mail->Body = "
                <h2>Restablecimiento de contraseña en FriendlyPets</h2>
                <p>Recibimos una solicitud para restablecer la contraseña de tu cuenta. Para continuar, haz clic en el siguiente enlace:</p>
                <p><a href='$resetLink'>Restablecer mi contraseña</a></p>
                <p>Si no solicitaste el restablecimiento de tu contraseña, por favor ignora este mensaje.</p>
                ";
                
                // Intentar enviar el correo
                if ($mail->send()) {
                    echo "Correo enviado correctamente a $email";
                } else {
                    echo "Error al enviar correo: " . $mail->ErrorInfo;
                }
            } catch (Exception $e) {
                error_log("Error enviando correo: " . $mail->ErrorInfo);
            }
        } else {
            echo "Correo no encontrado.";
        }
    }
    
    
    // Almacena el token de restablecimiento en la base de datos
    private function storePasswordResetToken($email, $token) {
        $db = DataBase::getInstance();
        $sSql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?";
        
        // El token expira después de 1 hora (puedes ajustarlo según tus necesidades)
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $sParam = array($token, $expiry, $email);
        return $db->executarSQL($sSql, $sParam);
    }
    

    public function getUserByResetToken($token) {
        $db = DataBase::getInstance();
        $sSql = "SELECT * FROM users WHERE reset_token = ?";
        $sParam = array($token);
        $result = $db->executarSQL($sSql, $sParam);
        
        if ($result && is_array($result) && count($result) > 0) {
            return $result[0]; // Retorna el primer usuario encontrado
        } else {
            return null; // Token no encontrado
        }
    }
    
    public function updatePassword($userId, $hashedPassword) {
        $db = DataBase::getInstance();
        $sSql = "UPDATE users SET password = ? WHERE id = ?";
        $sParam = array($hashedPassword, $userId);
        return $db->executarSQL($sSql, $sParam);
    }
    
    public function clearResetToken($userId) {
        $db = DataBase::getInstance();
        $sSql = "UPDATE users SET reset_token = NULL, reset_token_expiry = NULL WHERE id = ?";
        $sParam = array($userId);
        return $db->executarSQL($sSql, $sParam);
    }
    
    
    

    // // Supongamos que obtienes los datos de la base de datos en $user
    // $dogPicturesArray = json_decode($user['dog_pictures'], true);

    /**
     *
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     *
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     *
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     *
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     *
     * @return mixed
     */
    public function getBirthday()
    {
        return $this->birthday;
    }

    /**
     *
     * @return mixed
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     *
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     *
     * @return mixed
     */
    public function getCp()
    {
        return $this->cp;
    }

    /**
     *
     * @return mixed
     */
    public function getPoblacio()
    {
        return $this->poblacio;
    }

    /**
     *
     * @return mixed
     */
    public function getProvincia()
    {
        return $this->provincia;
    }

    /**
     *
     * @return mixed
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     *
     * @return mixed
     */
    public function getDog_name()
    {
        return $this->dog_name;
    }

    /**
     *
     * @return mixed
     */
    public function getDog_birthday()
    {
        return $this->dog_birthday;
    }

    /**
     *
     * @return mixed
     */
    public function getDog_gender()
    {
        return $this->dog_gender;
    }

    /**
     *
     * @return mixed
     */
    public function getDog_pictures()
    {
        return $this->dog_pictures;
    }

    /**
     *
     * @return mixed
     */
    public function getAgree()
    {
        return $this->agree;
    }

    /**
     *
     * @return mixed
     */
    public function getCreated_at()
    {
        return $this->created_at;
    }

    /**
     *
     * @return mixed
     */
    public function getUpdated_at()
    {
        return $this->updated_at;
    }

    /**
     *
     * @return mixed
     */
    public function getErrors()
    {
        return $this->errors;
    }

    /**
     *
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     *
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     *
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     *
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     *
     * @param mixed $birthday
     */
    public function setBirthday($birthday)
    {
        $this->birthday = $birthday;
    }

    /**
     *
     * @param mixed $gender
     */
    public function setGender($gender)
    {
        $this->gender = $gender;
    }

    /**
     *
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     *
     * @param mixed $cp
     */
    public function setCp($cp)
    {
        $this->cp = $cp;
    }

    /**
     *
     * @param mixed $poblacio
     */
    public function setPoblacio($poblacio)
    {
        $this->poblacio = $poblacio;
    }

    /**
     *
     * @param mixed $provincia
     */
    public function setProvincia($provincia)
    {
        $this->provincia = $provincia;
    }

    /**
     *
     * @param mixed $number
     */
    public function setNumber($number)
    {
        $this->number = $number;
    }

    /**
     *
     * @param mixed $dog_name
     */
    public function setDog_name($dog_name)
    {
        $this->dog_name = $dog_name;
    }

    /**
     *
     * @param mixed $dog_birthday
     */
    public function setDog_birthday($dog_birthday)
    {
        $this->dog_birthday = $dog_birthday;
    }

    /**
     *
     * @param mixed $dog_gender
     */
    public function setDog_gender($dog_gender)
    {
        $this->dog_gender = $dog_gender;
    }

    /**
     *
     * @param mixed $dog_pictures
     */
    public function setDog_pictures($dog_pictures)
    {
        $this->dog_pictures = $dog_pictures;
    }

    /**
     *
     * @param mixed $agree
     */
    public function setAgree($agree)
    {
        $this->agree = $agree;
    }

    /**
     *
     * @param mixed $created_at
     */
    public function setCreated_at($created_at)
    {
        $this->created_at = $created_at;
    }

    /**
     *
     * @param mixed $updated_at
     */
    public function setUpdated_at($updated_at)
    {
        $this->updated_at = $updated_at;
    }

    /**
     *
     * @param mixed $errors
     */
    public function setErrors($errors)
    {
        $this->errors = $errors;
    }
}

// public function getProfiles($current_user_id) {
//     $db = DataBase::getInstance();
    
//     $sSql = "SELECT id, name, dog_name, dog_birthday, dog_gender, dog_pictures
//              FROM users
//              WHERE verified = 1
//              AND id <> ?
//              AND id NOT IN (SELECT target_user_id FROM matches WHERE user_id = ?)";
    
//     $result = $db->executarSQL($sSql, [$current_user_id, $current_user_id]);
    
//     return ($result && is_array($result)) ? $result : [];
// }

// public function registerMatch($userId, $targetUserId, $action)
// {
//     $db = DataBase::getInstance();
    
//     // Insertar la acción en la base de datos
//     $sSql = "INSERT INTO matches (user_id, target_user_id, action) VALUES (?, ?, ?)
//              ON DUPLICATE KEY UPDATE action = VALUES(action)";
    
//     $stmt = $db->prepare($sSql);
//     $stmt->bind_param("iis", $userId, $targetUserId, $action);
//     $stmt->execute();
    
//     // Comprobar si ya hay un match mutuo
//     if ($action == "like") {
//         $checkSql = "SELECT * FROM matches WHERE user_id = ? AND target_user_id = ? AND action = 'like'";
//         $stmtCheck = $db->prepare($checkSql);
//         $stmtCheck->bind_param("ii", $targetUserId, $userId);
//         $stmtCheck->execute();
//         $result = $stmtCheck->get_result();
        
//         if ($result->num_rows > 0) {
//             return "¡Es un match!";
//         }
//     }
    
//     return "Acción registrada.";
// }

// public function saveMatch($user_id, $target_user_id, $action) {
//     $status = ($action == 'yes') ? 'pending' : 'unmatched';
    
//     $stmt = $this->db->prepare("INSERT INTO matches (user_id, target_user_id, action, status)
//                                 VALUES (?, ?, ?, ?)");
//     return $stmt->execute([$user_id, $target_user_id, $action, $status]);
// }

// public function checkMatch($user_id, $target_user_id) {
//     $stmt = $this->db->prepare("SELECT * FROM matches
//                                 WHERE user_id = ? AND target_user_id = ? AND action = 'yes'");
//     $stmt->execute([$target_user_id, $user_id]);
    
//     return $stmt->fetch(PDO::FETCH_ASSOC);
// }

// public function updateMatchStatus($user_id, $target_user_id) {
//     $stmt = $this->db->prepare("UPDATE matches
//                                 SET status = 'matched'
//                                 WHERE (user_id = ? AND target_user_id = ?)
//                                    OR (user_id = ? AND target_user_id = ?)");
//     return $stmt->execute([$user_id, $target_user_id, $target_user_id, $user_id]);
// }