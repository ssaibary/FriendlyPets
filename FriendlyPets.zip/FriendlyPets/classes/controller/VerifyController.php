<?php

class VerifyController extends Controller
{

    public function show()
    {
        session_start();

        $token = isset($_GET['token']) ? $_GET['token'] : null;

        $userModel = new User();
        $verifyView = new VerifyView();

        // Verificar el token en la base de datos
        $isValid = $userModel->verifyUserToken($token);

        if ($isValid) {
            // Si el token es válido, mostrar mensaje de éxito
            $_SESSION['message'] = '¡Tu cuenta ha sido verificada exitosamente!';
            $verifyView->show(); // Mostrar vista de verificación exitosa
        } else {
            // Si el token no es válido, mostrar mensaje de error
            $_SESSION['message'] = 'El token de verificación no es válido o ha expirado.';
            $verifyView->show([
                'El token proporcionado no es válido.'
            ]); // Pasar errores si es necesario
        }
    }
}

