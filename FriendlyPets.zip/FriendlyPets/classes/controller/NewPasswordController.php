<?php

class NewPasswordController extends Controller {
    
    public function __construct()
    {}
    
    public function show()
    {
        $vNewPassword = new NewPasswordView();
        $vNewPassword->show();
    }
    
    public function form_form($params)
    {
        $password = $this->sanitize($params["password"] ?? '');
        $cpassword = $this->sanitize($params["password2"] ?? '');
        $token = $this->sanitize($params["token"] ?? '');
        echo $token;
        
        if (($password == "") || ($cpassword == "")) {
            $errorsDetectats["pass"] = "La contraseña es obligatoria.";
        } else {
            if ($password != $cpassword) {
                $errorsDetectats["cpass"] = "Las contraseñas no coinciden.";
            } 
        }
        

        
        if (empty($errorsDetectats)) {
            $userModel = new User();
            $user = $userModel->getUserByResetToken($token);
            
            if ($user) {
                // El token es válido, ahora cambiamos la contraseña
                // Establecemos la nueva contraseña
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Actualizar la contraseña y limpiar el token
                $updateSuccess = $userModel->updatePassword($user['id'], $hashedPassword);
                
                if ($updateSuccess) {
                    // Limpiar los valores del token de restablecimiento
                    $userModel->clearResetToken($user['id']);
                    // Mostrar mensaje de éxito en pantalla
                    echo "<div style='color: green; text-align: center; padding: 10px;'>
                        Contraseña restablecida con éxito. <a href='/login.php'>Iniciar sesión</a>
                      </div>";
                    
//                     // Redirigir al login o mostrar un mensaje de éxito
//                     $_SESSION['message'] = "Contraseña restablecida con éxito. Puedes iniciar sesión.";
//                     header("Location: /login.php"); // Redirigir a la página de login
                    exit();
                } else {
                    $errorsDetectats["update"] = "Hubo un error al actualizar la contraseña. Intenta de nuevo.";
                }
            } else {
                $errorsDetectats["token"] = "El token de restablecimiento no es válido o ha expirado.";
            }
        }
        
        if (!empty($errorsDetectats)) {
            echo "<div style='color: red; text-align: center; padding: 10px;'>";
            foreach ($errorsDetectats as $error) {
                echo "<p>$error</p>";
            }
            echo "<a href='/reset-password.php?token=$token'>Volver</a></div>";
        }
    }
    
}

