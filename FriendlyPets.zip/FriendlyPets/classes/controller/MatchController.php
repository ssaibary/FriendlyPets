<?php

session_start();

class MatchController extends Controller {
    
    public function __construct()
    {}
    
    public function show() {
        $userModel = new MatchModel();
        $profiles = $userModel->getProfiles();
        
        $view = new MatchView();
        $view->show($profiles);
    }
    
    public function form_form($params) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(["success" => false, "error" => "Usuario no autenticado"]);
            exit;
        }
        
        $userId = $_SESSION['user_id'];
        $targetUserId = $params["matched_user_id"];
        $action = $params["is_like"] === "1" ? "yes" : "no";
        
        $userModel = new MatchModel();
        
        $match = $userModel->recordAction($userId, $targetUserId, $action);
        
        echo json_encode(["success" => true, "match" => $match]);
        exit;
    }
    
}



// DATABASE
// CREATE TABLE matches (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     user_id INT NOT NULL,        -- Usuario que da el like/no like
//     target_user_id INT NOT NULL, -- Usuario que recibe la acción
//     action ENUM('yes', 'no') NOT NULL, -- Acción tomada
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//     FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
//     FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE CASCADE
//     );

// PARA VER UN MATCH
// UPDATE matches m1
// JOIN matches m2 ON m1.user_id = m2.target_user_id AND m1.target_user_id = m2.user_id
// SET m1.status = 'matched', m2.status = 'matched'
// WHERE m1.action = 'like' AND m2.action = 'like' AND m1.status = 'pending' AND m2.status = 'pending';

// ELIMIAR MATCH
// UPDATE matches
// SET status = 'unmatched'
// WHERE (user_id = ? AND target_user_id = ?)
// OR (user_id = ? AND target_user_id = ?);
