<?php

class RegisterController extends Controller
{

    public function __construct()
    {}

    public function show()
    {
        $vHome = new RegisterView();
        $vHome->show();
    }

    
    public function form_show($params)
    {
        $name = $this->sanitize($params["name"] ?? '');
        $email = $this->sanitize($params["email"] ?? '');
        $password = $this->sanitize($params["password"] ?? '');
        $cpassword = $this->sanitize($params["password2"] ?? '');
        $birthday = $this->sanitize($params["birthday"] ?? '');
        $gender = $this->sanitize($params["gender"] ?? '');
        $address = $this->sanitize($params["address"] ?? '');
        $codiPostal = $this->sanitize($params["cp"] ?? '');
        $poblacio = $this->sanitize($params["poblacio"]);
        $provincia = $this->sanitize($params["provincia"] ?? '');
        $telefon = $this->sanitize($params["number"] ?? '');
        $errorsDetectats = [];

        $user = new User();

        if ($name == "") {
            $errorsDetectats["nom"] = "El nombre es obligatorio.";
        } else {
            if (! $this->validateItem($name, "name")) {
                $errorsDetectats["nom"] = "El nombre contiene caracteres no permitidos.";
            } else {
                $user->name = $name;
            }
        }

        if ($email == "") {
            $errorsDetectats["email"] = "El email es obligatorio.";
        } else {
            if (! $this->validateItem($email, "email")) {
                $errorsDetectats["email"] = "El email no tiene un formato válido.";
            } else {
                $user->email = $email;
            }
        }

        if (($password == "") || ($cpassword == "")) {
            $errorsDetectats["pass"] = "La contraseña es obligatoria.";
        } else {
            if ($password != $cpassword) {
                $errorsDetectats["cpass"] = "Las contraseñas no coinciden.";
            } else {
                $user->setPassword($password);
            }
        }

        $tipusValids = array(
            "Male",
            "Female",
            "Other"
        );
        if (! in_array($gender, $tipusValids)) {
            $errorsDetectats["sexe"] = "Hubo un problema con la selección del género.";
        } else {
            $user->gender = $gender;
        }

        if ($birthday == "") {
            $errorsDetectats["dNaixement"] = "La fecha de nacimiento es obligatoria.";
        } else {
            $birthdayDate = DateTime::createFromFormat('Y-m-d', $birthday);

            if (! $birthdayDate) {
                $errorsDetectats["dNaixement"] = "Formato de fecha inválido.";
            } else {
                $today = new DateTime();
                $minAge = $today->modify('-18 years'); // Mínimo 18 años
                $oldestAllowed = new DateTime('1900-01-01'); // No antes de 1900

                if ($birthdayDate > $minAge) {
                    $errorsDetectats["dNaixement"] = "Debes tener al menos 18 años.";
                } elseif ($birthdayDate < $oldestAllowed) {
                    $errorsDetectats["dNaixement"] = "La fecha de nacimiento es demasiado antigua.";
                } else {
                    $user->birthday = $birthday;
                }
            }
        }

        if ($address == "") {
            $errorsDetectats["address"] = "La dirreción es obligatoria";
        } else {
            if ($address != "" && (! $this->validateItem($address, "address"))) {
                $errorsDetectats["address"] = "El format de la dirreció es incorrecte.";
            } else {
                $user->address = $address;
            }
        }

        if ($poblacio == "") {
            $errorsDetectats["poblacio"] = "La poblacion es obligatoria.";
        } else {
            if (($poblacio != "") && (! $this->validateItem($poblacio, "name"))) {
                $errorsDetectats["poblacio"] = "La poblacio té un format incorrecte.";
            } else {
                $user->poblacio = $poblacio;
            }
        }

        if ($codiPostal == "") {
            $errorsDetectats["cp"] = "El codi postal es obligatori.";
        } else {
            if (($codiPostal != "") && (! $this->esCodiPostal($codiPostal))) {
                $errorsDetectats["cp"] = "El codi postal no correspon a cap població.";
            } else {
                $user->cp = $codiPostal;
            }
        }

        if ($provincia == "") {
            $errorsDetectats["provincia"] = "La provincia es obligatoria.";
        } else {
            if (($provincia != "") && (! $this->esProvincia(strtolower($provincia)))) {
                $errorsDetectats["provincia"] = "La provincia no és una de les espanyoles.";
            } else {
                $user->provincia = $provincia;
            }
        }

        if ($telefon == "") {
            $errorsDetectats["telefon"] = "El numero de telèfon es obligatori";
        } else {
            if (($telefon != "") && (! $this->validateItem($telefon, "phone"))) {
                $errorsDetectats["telefon"] = "El format del telèfon no és correcte.";
            } else {
                $user->number = $telefon;
            }
        }

        // Validación de datos del perro
        $dogName = $this->sanitize($params["dog-name"] ?? '');
        $dogBirthday = $this->sanitize($params["dog-birthday"] ?? '');
        $dogGender = $this->sanitize($params["dog-gender"] ?? '');

        $agree = isset($params["agree"]);

        if ($dogName == "") {
            $errorsDetectats["dogName"] = "El nombre del perro es obligatorio.";
        } else {
            if (! $this->validateItem($dogName, "alfanum")) {
                $errorsDetectats["dogName"] = "El nombre del perro contiene caracteres no permitidos.";
            } else {
                $user->dog_name = $dogName;
            }
        }

        if ($dogBirthday == "") {
            $errorsDetectats["dogBirthday"] = "La fecha de nacimiento del perro es obligatoria.";
        } else {
            $birthdayDogDate = DateTime::createFromFormat('Y-m-d', $dogBirthday);

            if (! $birthdayDogDate) {
                $errorsDetectats["dogBirthday"] = "Formato de fecha inválido.";
            } else {
                $today = new DateTime();
                $oldestAllowed = new DateTime('1980-01-01');

                if ($birthdayDogDate < $oldestAllowed) {
                    $errorsDetectats["dogBirthday"] = "La fecha de nacimiento es demasiado antigua.";
                }

                if ($birthdayDogDate > $today) {
                    $errorsDetectats["dogBirthday"] = "La fecha de nacimiento es incorrecta.";
                } else {
                    $user->dog_birthday = $dogBirthday;
                }
            }
        }

        $dogValidGenders = array(
            "Male",
            "Female"
        );
        if (! in_array($dogGender, $dogValidGenders)) {
            $errorsDetectats["dogGender"] = "Hubo un problema con la selección del género del perro.";
        } else {
            $user->dog_gender = $dogGender;
        }

        if (! $agree) {
            $errorsDetectats["agree"] = "Debes aceptar los términos y condiciones.";
        } else {
            $user->agree = true;
        }

        // Validación de imágenes
        if (empty($errorsDetectats)) {
            $directoriDePujades = "../uploads/"; // Carpeta donde almacenaremos las imágenes subidas
            $formatsImatgesPermesos = array(
                'jpg',
                'jpeg',
                'gif',
                'png',
                'tif',
                'tiff',
                'bmp'
            ); // Formatos permitidos
            $mimesImatgesPermesos = array(
                "image/jpg",
                "image/jpeg",
                "image/png",
                "image/gif",
                "image/tif",
                "image/tiff",
                "image/bmp"
            );

            // Comprobamos si se han subido archivos
            if (isset($_FILES['dog-pictures']['name']) && is_array($_FILES['dog-pictures']['name'])) {
                $fileCount = count($_FILES['dog-pictures']['name']); // Número de archivos subidos

                // Recorremos cada archivo subido
                for ($i = 0; $i < $fileCount; $i ++) {
                    // Cargar información del archivo actual
                    $imatge = $_FILES['dog-pictures']['tmp_name'][$i]; // Nombre temporal del archivo
                    $nomOriginal = $_FILES['dog-pictures']['name'][$i]; // Nombre original del archivo
                    $tamany = $_FILES['dog-pictures']['size'][$i]; // Tamaño del archivo en bytes
                    $error = $_FILES['dog-pictures']['error'][$i]; // Error del archivo
                    $tipus = $_FILES['dog-pictures']['type'][$i]; // Tipo MIME del archivo

                    // Si no hay error en la carga
                    if ($error === 0) {
                        $aNom = explode('.', $nomOriginal); // Obtener la extensión del archivo
                        $aNomLong = count($aNom); // Longitud del array
                        $sExtensio = strtolower($aNom[-- $aNomLong]);

                        // Verificar si la extensión y MIME son correctos
                        if (in_array($sExtensio, $formatsImatgesPermesos)) {
                            if (in_array($tipus, $mimesImatgesPermesos)) {
                                if ($tamany > 2097152) { // Tamaño máximo de 2MB
                                    $errorsDetectats["dog-pictures"] = "Error2013 - Tamaño excesivo del archivo";
                                } else {
                                    // Crear un nombre único para el archivo
                                    $nomNou = microtime(true) . '_' . $nomOriginal;
                                    $rutaNova = $directoriDePujades . $nomNou; // Ruta completa del archivo

                                    // Mover el archivo a la carpeta de destino
                                    $result = move_uploaded_file($imatge, $rutaNova);

                                    // Si el archivo se movió correctamente
                                    if ($result) {
                                        // Agregar la ruta de la imagen al array (puedes usar un array para todas las imágenes)
                                        $user->dog_pictures[] = $rutaNova; // Asumiendo que tienes un array de imágenes en el objeto 'usuari'
                                    } else {
                                        $errorsDetectats["dog-pictures"] = "Error2014 - Problemas al mover el archivo definitivo";
                                    }
                                }
                            } else {
                                $errorsDetectats["dog-pictures"] = "Error2012 - El formato interno del archivo no está permitido";
                            }
                        } else {
                            $errorsDetectats["dog-pictures"] = "Error2011 - Tipo de archivo con extensión no permitida";
                        }
                    } else {
                        // Si ocurrió un error al subir el archivo (no es el error de 'ningún archivo')
                        if ($error != 4) {
                            $errorsDetectats["dog-pictures"] = "Error2010 - No se ha subido el archivo. Error: " . $error;
                        }
                    }
                }
            }
        }

        if (! empty($errorsDetectats)) {
            $vRegister = new RegisterView();
            $vRegister->show($errorsDetectats, $params);
            return;
        }

        if (empty($errorsDetectats)) {
            $miObjeto = new User();
            $miObjeto->register($user);
            echo "OK";
            exit();
        }
    }
}
