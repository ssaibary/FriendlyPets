<?php 

class LegalController extends View {
    
    public function show()
    {
        $vLegal = new LegalView();
        $vLegal->show();
    }
    
}

