<?php

class LoginController extends Controller
{

    public function __construct()
    {}

    public function show()
    {
        $vHome = new LoginView();
        $vHome->show();
    }

    // Procesa el formulario de login
    public function form_show($params)
    {
        session_start();
        
        $email = $this->sanitize($params["email"] ?? '');
        $password = $this->sanitize($params["password"] ?? '');

        $errorsDetectats = [];

        // Validaciones básicas
        if (empty($email)) {
            $errorsDetectats["email"] = "El correo es obligatorio.";
        }
        if (empty($password)) {
            $errorsDetectats["password"] = "La contraseña es obligatoria.";
        }

        // Si hay errores, volver a mostrar el formulario con errores
        if (! empty($errorsDetectats)) {
            $vLogin = new LoginView();
            $vLogin->show($errorsDetectats, $params);
            return;
        }

        // Validar credenciales en la base de datos
        $userModel = new User();
        $user = $userModel->getUserByEmail($email);

        if ($user) {
            // Verificar si el usuario está verificado
            if (! $user["verified"]) {
                $errorsDetectats["login"] = "Cuenta no verificada. Por favor revisa tu correo.";
            } else {
                // Verificar la contraseña
                if (password_verify($password, $user["password"])) {
                    // Iniciar sesión y guardar datos del usuario
                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["user_name"] = $user["name"];
                    $_SESSION["user_email"] = $user["email"];

                    // Redirigir al dashboard u otra página
                    header("Location: ?Match/show");
                    exit();
                } else {
                    $errorsDetectats["login"] = "Correo o contraseña incorrectos.";
                }
            }
        } else {
            $errorsDetectats["login"] = "Correo o contraseña incorrectos.";
        }

        // Si la autenticación falla, mostrar la vista con errores
        $vLogin = new LoginView();
        $vLogin->show($errorsDetectats, $params);
        
    }
}

