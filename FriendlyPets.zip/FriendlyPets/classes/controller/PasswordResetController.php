<?php

class PasswordResetController extends Controller {
    
    public function __construct()
    {}
    
    public function show()
    {
        $vPasswordReset = new PasswordResetView();
        $vPasswordReset->show();
    }
    
    public function form_form($params)
    {
        $email = $this->sanitize($params["email"] ?? '');
        
        $errorsDetectats = [];
        
        // Validaciones básicas
        if (empty($email)) {
            $errorsDetectats["email"] = "El correo es obligatorio.";
        }
        
        $userModel = new User();
        $user = $userModel->getUserByEmail($email);
        
        if ($user) {
            // llamar aqui 
            $userModel->sendPasswordReset($email);
            
            
        } else {
            $errorsDetectats["login"] = "Correo no encontrado.";
        }
        
    }
    
}

