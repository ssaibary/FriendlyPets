<?php

session_start();

class ChatController extends Controller  {
    
    public function show() {
        $chatModel = new ChatModel();
        $userId = $_SESSION['user_id'];
        $matches = $chatModel->getMatches($userId);
        
        
        $view = new ChatView();
        $view->show($matches);
    }
    
    public function getMessages($params) {
                
        header('Content-Type: application/json');
          
        $userId = $_SESSION['user_id'];
        $targetUserId = $params[0];
      
        $chatModel = new ChatModel();
        $messages = $chatModel->getMessages($userId, $targetUserId);

        echo json_encode($messages);
    }
    
    public function form_form($params) {
        
        $userId = $_SESSION['user_id'];
        $targetUserId = $params["receiver_id"];
        $message = $params["message"];
        
        $chatModel = new ChatModel();
        
        $chatModel->sendMessage($userId, $targetUserId, $message);
        
        echo json_encode(["success" => true]);
    }
    
}