<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/terms.css">
    <title>Política de Privacidad | FriendlyPets</title>
</head>
<body>
    <header>
        <h1>Política de Privacidad</h1>
    </header>
    <main>
        <section>
            <h2>1. Introducción</h2>
            <p>En FriendlyPets, respetamos tu privacidad y estamos comprometidos a proteger tus datos personales. Esta política describe cómo recopilamos, usamos y compartimos tu información.</p>
        </section>

        <section>
            <h2>2. Información que Recopilamos</h2>
            <p>Recopilamos información personal cuando te registras, como tu nombre, correo electrónico, información sobre tu perro y fotos. También recopilamos datos técnicos como tu dirección IP y detalles del dispositivo.</p>
        </section>

        <section>
            <h2>3. Uso de la Información</h2>
            <p>Usamos tu información para:
                <ul>
                    <li>Proveer nuestros servicios y personalizar tu experiencia.</li>
                    <li>Comunicarnos contigo sobre actualizaciones y promociones.</li>
                    <li>Mejorar nuestra plataforma mediante análisis de datos.</li>
                </ul>
            </p>
        </section>

        <section>
            <h2>4. Compartir Información</h2>
            <p>No compartimos tu información personal con terceros sin tu consentimiento, excepto en los siguientes casos:
                <ul>
                    <li>Proveedores de servicios que nos ayudan a operar nuestra plataforma.</li>
                    <li>Cuando sea requerido por ley o para proteger nuestros derechos.</li>
                </ul>
            </p>
        </section>

        <section>
            <h2>5. Seguridad de los Datos</h2>
            <p>Implementamos medidas de seguridad para proteger tu información, pero no podemos garantizar la seguridad absoluta. Es importante que protejas tu cuenta y contraseña.</p>
        </section>

        <section>
            <h2>6. Cookies</h2>
            <p>Usamos cookies para mejorar tu experiencia en el sitio. Puedes gestionar tus preferencias de cookies en la configuración de tu navegador.</p>
        </section>

        <section>
            <h2>7. Tus Derechos</h2>
            <p>Tienes derecho a acceder, corregir o eliminar tu información personal. Contáctanos en cualquier momento para ejercer estos derechos.</p>
        </section>

        <section>
            <h2>8. Cambios a esta Política</h2>
            <p>Podemos actualizar esta política ocasionalmente. Publicaremos los cambios en esta página y te notificaremos si son significativos.</p>
        </section>

        <section>
            <h2>9. Contacto</h2>
            <p>Si tienes preguntas sobre nuestra política de privacidad, contáctanos en <a href="mailto:privacidad@friendlypets.com">privacidad@friendlypets.com</a>.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 FriendlyPets. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
