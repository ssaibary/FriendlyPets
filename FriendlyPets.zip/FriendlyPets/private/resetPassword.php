<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/register.css" />
<script defer type="text/javascript" src="../js/register.js"></script>
<title>LogIn</title>
</head>

<body>
	<form method="POST" id="login-form">
		<h1>Crear nueva contraseña</h1>
		<input type="hidden" name="token"
			value="<?= htmlspecialchars($_GET['token'] ?? '') ?>"> <label
			for="password">Contraseña nueva</label> <input type="password"
			id="password" name="password"
			placeholder="<?= isset($errors['pass']) ? $errors['pass'] : 'Contraseña' ?>">

		<label for="password2">Repetir Contraseña</label> <input
			type="password" id="password2" name="password2"
			placeholder="<?= isset($errors['cpass']) ? $errors['cpass'] : 'Repite tu Contraseña' ?>">
		<button type="submit" name="submit">Entrar</button>

	</form>
</body>
</html>