<?php
?>

<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/register.css">
<script defer type="text/javascript" src="../js/register.js"></script>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<title>Registro</title>
</head>

<body>
	<form method="POST" id="register-form" enctype="multipart/form-data">
		<div class="title">
			<a style="color: black;" href="index.php"><strong>X</strong></a>
			<h1>Registro</h1>
		</div>

		<!-- Paso 1 -->
		<div id="step1" class="form-step active">
			<h2>Información del Usuario</h2>
			<label for="name">Nombre</label> <input type="text" id="name"
				name="name"
				value="<?= isset($name) && !isset($errors['nom']) ? htmlspecialchars($name) : '' ?>"
				placeholder="<?= isset($errors['nom']) ? $errors['nom'] : 'Tu Nombre' ?>">

			<label for="email">Correo</label> <input id="email" name="email"
				value="<?= isset($email) && !isset($errors['email']) ? htmlspecialchars($email) : '' ?>"
				placeholder="<?= isset($errors['email']) ? $errors['email'] : 'Tu Correo electrónico' ?>">


			<label for="password">Contraseña</label>
			<div class="password-container">

				<input type="password" id="password" name="password"
					placeholder="<?= isset($errors['pass']) ? $errors['pass'] : 'Contraseña' ?>">
				<span class="password-toggle-icon"><i class="fas fa-eye"></i></span>
			</div>
			<label for="password2">Repetir Contraseña</label>
			<div class="password-container">

				<input type="password" id="password2" name="password2"
					placeholder="<?= isset($errors['cpass']) ? $errors['cpass'] : 'Repite tu Contraseña' ?>">
				<span class="password-toggle-icon"><i class="fas fa-eye"></i></span>
			</div>


			<label for="birthday">Fecha de Nacimiento</label> <input type="date"
				id="birthday" name="birthday"
				value="<?= isset($birthday) && !isset($errors['dNaixement']) ? htmlspecialchars($birthday) : '' ?>">
			<div class="error" id="agree-error"> <?= isset($errors['dNaixement']) ? $errors['dNaixement'] : '' ?> </div>

			<label class="gender-label">Género</label>
			<div id="gender">
				<div class="gender">
					<label for="male">Hombre</label> <input type="radio" id="male"
						name="gender" value="Male"
						<?= isset($gender) && !isset($errors['sexe']) && $gender === 'Male' ? 'checked' : '' ?>>
				</div>
				<div class="gender">
					<label for="female">Mujer</label> <input type="radio" id="female"
						name="gender" value="Female"
						<?= isset($gender) && !isset($errors['sexe']) && $gender === 'Female' ? 'checked' : '' ?>>
				</div>
				<div class="gender">
					<label for="other">Otro</label> <input type="radio" id="other"
						name="gender" value="Other"
						<?= isset($gender) && !isset($errors['sexe']) && $gender === 'Other' ? 'checked' : '' ?>>
				</div>
			</div>
			<div class="error" id="gender-error"> <?= isset($errors['sexe']) ? $errors['sexe'] : '' ?> </div>

			<button type="button" class="next-btn">Siguiente</button>
			<div class="account">
				<p style="text-align: center;">
					Tienes cuenta --> <a href="?Login/show">Iniciar Sessión</a>
				</p>
			</div>

		</div>

		<!-- Paso 2 -->
		<div id="step2" class="form-step" style="margin-top: 20px;">
			<label for="address">Dirección</label> <input type="text"
				id="address" name="address"
				value="<?= isset($address) && !isset($errors['address']) ? htmlspecialchars($address) : '' ?>"
				placeholder="<?= isset($errors['address']) ? $errors['address'] : 'Dirreción' ?>">

			<label for="cp">C.P</label> <input id="cp" name="cp"
				inputmode="numeric" pattern="\d{5}" maxlength="5"
				value="<?= isset($cp) && !isset($errors['cp']) ? htmlspecialchars($cp) : '' ?>"
				placeholder="<?= isset($errors['cp']) ? $errors['cp'] : 'C.P' ?>"> <label
				for="poblacio">Población</label> <input type="text" id="poblacio"
				name="poblacio"
				value="<?= isset($poblacio) && !isset($errors['poblacio']) ? htmlspecialchars($poblacio) : '' ?>"
				placeholder="<?= isset($errors['poblacio']) ? $errors['poblacio'] : 'Población' ?>">

            <label for="provincia">Provincia</label> <br>
            <select id="provincia" name="provincia">
                <option value="">Seleccione una provincia</option>
                <?php 
                $provincias = array(
                    'Álava','Albacete','Alicante','Almería','Asturias','Ávila','Badajoz','Barcelona','Burgos','Cáceres','Cádiz',
                    'Cantabria','Castellón','Ciudad Real','Córdoba','La Coruña','Cuenca','Girona','Granada','Guadalajara','Guipúzcoa',
                    'Huelva','Huesca','Islas Baleares','Jaén','León','Lleida','Lugo','Madrid','Málaga','Murcia','Navarra','Orense',
                    'Palencia','Las Palmas','Pontevedra','La Rioja','Salamanca','Segovia','Sevilla','Soria','Tarragona',
                    'Santa Cruz de Tenerife','Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza'
                );
                foreach ($provincias as $prov) : 
                    $selected = (isset($provincia) && strtolower($provincia) == strtolower($prov)) ? 'selected' : '';
                ?>
                    <option value="<?= htmlspecialchars($prov) ?>" <?= $selected ?>><?= ucfirst($prov) ?></option>
                <?php endforeach; ?>
            </select>
            <div class="error"><?= isset($errors['provincia']) ? $errors['provincia'] : '' ?></div>


			<label for="number">Número</label>
			<div class="phone-input-container">
				<span class="prefix">+34</span> <input type="tel" id="number"
					name="number" inputmode="numeric" maxlength="9"
					value="<?= isset($number) && !isset($errors['telefon']) ? htmlspecialchars($number) : '' ?>"
					placeholder="<?= isset($errors['telefon']) ? $errors['telefon'] : 'Número de teléfono' ?>">
			</div>



			<button type="button" class="next-btn" style="margin-top: 30px;">Siguiente</button>
			<button type="button" class="prev-btn">Atrás</button>
		</div>

		<!-- Paso 3 -->
		<div id="step3" class="form-step">
			<h2>Información del Perro</h2>
			<label for="dog-name">Nombre</label> <input type="text" id="dog-name"
				name="dog-name"
				value="<?= isset($dog_name) && !isset($errors['dogName']) ? htmlspecialchars($dog_name) : '' ?>"
				placeholder="<?= isset($errors['dogName']) ? $errors['dogName'] : 'Nombre del Perro' ?>">

			<label for="dog-birthday">Fecha de Nacimiento</label> <input
				type="date" id="dog-birthday" name="dog-birthday"
				value="<?= isset($dog_birthday) && !isset($errors['dNaixement']) ? htmlspecialchars($dog_birthday) : '' ?>">
			<div class="error" id="agree-error"> <?= isset($errors['dogBirthday']) ? $errors['dogBirthday'] : '' ?> </div>
			<label class="gender-label" for="dog-gender">Género</label>
			<div id="dog-gender">
				<div class="dog-gender">
					<label for="dog-male">Macho</label> <input type="radio"
						id="dog-male" name="dog-gender" value="Male"
						<?= isset($dog_gender) && $dog_gender === 'Male' ? 'checked' : '' ?>>
				</div>
				<div class="dog-gender">
					<label for="dog-female">Hembra</label> <input type="radio"
						id="dog-female" name="dog-gender" value="Female"
						<?= isset($dog_gender) && $dog_gender === 'Female' ? 'checked' : '' ?>>
				</div>
			</div>
			<div class="error" id="dog-gender-error"> <?= isset($errors['dogGender']) ? $errors['dogGender'] : '' ?> </div>

<!-- 			<label for="dog-pictures">Subir Fotos</label> <input type="file" -->
<!-- 				id="dog-pictures" name="dog-pictures[]" multiple accept="image/*"> -->
<!-- 			<div id="preview-container"></div> -->

		<!-- Subir fotos de tu perro -->
            <label for="dog-pictures">Subir fotos de tu perro</label>
            <div class="upload-area" id="upload-area">
                <i class="fas fa-cloud-upload-alt"></i>
                <p>Haz clic o arrastra las imágenes aquí</p>
            </div>
            <input type="file" id="dog-pictures" name="dog-pictures[]" accept="image/*" multiple style="display:none;">
            <div id="preview-container"></div>


			<div id="terms">
				<label for="agree">Acepto los <a href="?Legal/show" target="_blank">términos
						y condiciones</a></label> <input type="checkbox" id="agree"
					name="agree">
			</div>
			<div class="error" id="agree-error"> <?= isset($errors['agree']) ? $errors['agree'] : '' ?> </div>
			<br>

			<button type="submit" name="submit">Registrar</button>
			<button type="button" class="prev-btn">Atrás</button>
		</div>
	</form>
</body>

</html>

<!-- 
PENDETS

Verificació de nombre aceptar caracteres especiales
No permitir una fecha para un menor de 18 años


 -->



<!-- USUARI -->
<!-- Nom -->
<!-- Email -->
<!-- Contrasenya -->
<!-- Fecha de Nacimiento -->
<!-- Genero -->
<!-- Ubicación -->
<!-- Numero -->


<!-- PERRO -->
<!-- Nom -->
<!-- Fecha de Nacimiento -->
<!-- Fotos -->
<!-- Genero -->


<!-- Aceptar Terminos -->
<!-- Verificacion de Correo -->
<!-- Tienes cuenta ? -->
<!-- No tienes cuenta ? -->
<!-- Google Facebook -->
<!-- Contraseña olvidada -->
<!-- Terminos -->


