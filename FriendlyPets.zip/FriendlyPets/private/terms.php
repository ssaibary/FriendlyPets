<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/terms.css">
    <title>Términos y Condiciones | FriendlyPets</title>
</head>
<body>
    <header>
        <h1>Términos y Condiciones</h1>
    </header>
    <main>
        <section>
            <h2>1. Introducción</h2>
            <p>Bienvenido a FriendlyPets. Al utilizar nuestro sitio web, aceptas cumplir con estos términos y condiciones. Si no estás de acuerdo, por favor, no utilices nuestro servicio.</p>
        </section>

        <section>
            <h2>2. Uso del Servicio</h2>
            <p>FriendlyPets es una plataforma diseñada para conectar dueños de perros de manera segura y divertida. Los usuarios deben ser mayores de 18 años y proporcionar información precisa al registrarse.</p>
        </section>

        <section>
            <h2>3. Cuentas y Seguridad</h2>
            <p>Es tu responsabilidad mantener la seguridad de tu cuenta. No compartas tu contraseña con terceros y notifícanos inmediatamente en caso de actividad no autorizada.</p>
        </section>

        <section>
            <h2>4. Contenido Generado por los Usuarios</h2>
            <p>Los usuarios son responsables del contenido que publican. No se permite publicar contenido ofensivo, ilegal o que viole derechos de terceros.</p>
        </section>

        <section>
            <h2>5. Planes de Suscripción</h2>
            <p>FriendlyPets ofrece una versión gratuita y una versión premium. Consulta nuestra página de precios para más detalles. Las suscripciones no son reembolsables.</p>
        </section>

        <section>
            <h2>6. Política de Privacidad</h2>
            <p>Al usar FriendlyPets, aceptas nuestra <a href="privacy.php">Política de Privacidad</a>, que detalla cómo recopilamos, usamos y protegemos tus datos.</p>
        </section>

        <section>
            <h2>7. Cambios en los Términos</h2>
            <p>Nos reservamos el derecho de modificar estos términos en cualquier momento. Las actualizaciones se publicarán en esta página, y tu uso continuo del servicio constituye tu aceptación.</p>
        </section>

        <section>
            <h2>8. Contacto</h2>
            <p>Si tienes preguntas sobre estos términos, contáctanos en <a href="mailto:soporte@friendlypets.com">soporte@friendlypets.com</a>.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 FriendlyPets. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
