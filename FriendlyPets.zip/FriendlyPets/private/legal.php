<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/legal.css">
    <title>Términos y Política de Privacidad | FriendlyPets</title>
</head>
<body>
    <header>
        <h1>Términos y Política de Privacidad</h1>
    </header>
    <nav>
        <ul>
            <li><a href="#terminos">Términos y Condiciones</a></li>
            <li><a href="#privacidad">Política de Privacidad</a></li>
        </ul>
    </nav>
    <main>
        <section id="terminos">
            <h2>1. Términos y Condiciones</h2>
            <p>Bienvenido a FriendlyPets. Al utilizar nuestro sitio web, aceptas cumplir con estos términos y condiciones. Si no estás de acuerdo, por favor, no utilices nuestro servicio.</p>

            <h3>2. Uso del Servicio</h3>
            <p>FriendlyPets es una plataforma diseñada para conectar dueños de perros de manera segura y divertida. Los usuarios deben ser mayores de 18 años y proporcionar información precisa al registrarse.</p>

            <h3>3. Cuentas y Seguridad</h3>
            <p>Es tu responsabilidad mantener la seguridad de tu cuenta. No compartas tu contraseña con terceros y notifícanos inmediatamente en caso de actividad no autorizada.</p>

            <h3>4. Contenido Generado por los Usuarios</h3>
            <p>Los usuarios son responsables del contenido que publican. No se permite publicar contenido ofensivo, ilegal o que viole derechos de terceros.</p>

            <h3>5. Planes de Suscripción</h3>
            <p>FriendlyPets ofrece una versión gratuita y una versión premium. Consulta nuestra página de precios para más detalles. Las suscripciones no son reembolsables.</p>

            <h3>6. Cambios en los Términos</h3>
            <p>Nos reservamos el derecho de modificar estos términos en cualquier momento. Las actualizaciones se publicarán en esta página, y tu uso continuo del servicio constituye tu aceptación.</p>
        </section>

        <hr>

        <section id="privacidad">
            <h2>2. Política de Privacidad</h2>
            <p>En FriendlyPets, respetamos tu privacidad y estamos comprometidos a proteger tus datos personales. Esta política describe cómo recopilamos, usamos y compartimos tu información.</p>

            <h3>Información que Recopilamos</h3>
            <p>Recopilamos información personal cuando te registras, como tu nombre, correo electrónico, información sobre tu perro y fotos. También recopilamos datos técnicos como tu dirección IP y detalles del dispositivo.</p>

            <h3>Uso de la Información</h3>
            <ul>
                <li>Proveer nuestros servicios y personalizar tu experiencia.</li>
                <li>Comunicarnos contigo sobre actualizaciones y promociones.</li>
                <li>Mejorar nuestra plataforma mediante análisis de datos.</li>
            </ul>

            <h3>Seguridad de los Datos</h3>
            <p>Implementamos medidas de seguridad para proteger tu información, pero no podemos garantizar la seguridad absoluta. Es importante que protejas tu cuenta y contraseña.</p>

            <h3>Tus Derechos</h3>
            <p>Tienes derecho a acceder, corregir o eliminar tu información personal. Contáctanos en cualquier momento para ejercer estos derechos.</p>
        </section>

        <hr>

        <section>
            <h2>Contacto</h2>
            <p>Si tienes preguntas, contáctanos en:</p>
            <ul>
                <li>Email soporte: <a href="mailto:soporte@friendlypets.com">soporte@friendlypets.com</a></li>
                <li>Email privacidad: <a href="mailto:privacidad@friendlypets.com">privacidad@friendlypets.com</a></li>
            </ul>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 FriendlyPets. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
