<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header("Location: ?Login/show");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Chat - FriendlyPets</title>
<link rel="icon" type="../image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/match.css" />
<link rel="stylesheet" href="../css/chat.css" />
<script defer type="text/javascript" src="../js/chat.js"></script>
<script>
    const currentUserId = <?php echo json_encode($userId); ?>;
</script>
<script defer type="text/javascript" src="../js/chat.js"></script>
</head>
<body>
    <!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar">
            <a href="index.php" class="navbar-brand">FriendlyPets</a>
            <button class="menu-toggle" onclick="toggleMenu()">☰</button>
            <div id="nav" class="navbar-nav">
                <a href="?Match/show" class="nav-link">Match</a> 
                <a href="?Chat/show" class="nav-link">Chat</a> 
                <a href="?Profile/show" class="nav-link">Profile</a>
            </div>
        </nav>
    </div>

    <div class="chat-container">
        <div class="chat-list">
            <h2>Matches ❤️</h2>
            <ul id="match-list">
            <?php if ($matches): ?>
                    <?php foreach ($matches as $match): ?>
                        <li onclick="openChat('<?php echo $match['id']; ?>')">
                            🐶 <?php echo htmlspecialchars($match['name']); ?>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li>No tienes matches aún.</li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="chat-box" id="chatBox">
            <p id="placeholder-text">Charla con alguien 🐾</p>
            <div class="messages" id="messages" style="display: none"></div>
            <div class="input-box" id="inputBox" style="display: none">
                <input type="text" id="messageInput" placeholder="Escribe un mensaje..." />
                <button onclick="sendMessage()">Enviar 🚀</button>
            </div>
        </div>
    </div>
</body>
</html>
