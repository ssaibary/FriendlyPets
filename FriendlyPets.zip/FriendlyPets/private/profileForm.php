<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editar Perfil</title>
<link rel="stylesheet" href="../css/profile.css">
<link rel="stylesheet" href="../css/profileForm.css">
<script defer type="text/javascript" src="../js/profileForm.js"></script>
</head>
<body>
    <div class="profile-container">
        <h1>Editar Perfil</h1>
        <form id="edit-profile-form">
            <h2>Información del Usuario</h2>
            <label for="name">Nombre</label> 
            <input type="text" id="name" name="name" placeholder="Tu Nombre">
            
            <label for="email">Correo</label>
            <input type="email" id="email" name="email" placeholder="Tu Correo" disabled>
            
            <label for="birthday">Fecha de Nacimiento</label>
            <input type="date" id="birthday" name="birthday">
            
            <label>Género</label>
            <div class="gender-options">
                <label><input type="radio" name="gender" value="Male"> Hombre</label>
                <label><input type="radio" name="gender" value="Female"> Mujer</label>
                <label><input type="radio" name="gender" value="Other"> Otro</label>
            </div>

            <h2>Información del Perro</h2>
            <label for="dog-name">Nombre del Perro</label> 
            <input type="text" id="dog-name" name="dog-name" placeholder="Nombre del Perro"> 
            
            <label for="dog-birthday">Fecha de Nacimiento</label> 
            <input type="date" id="dog-birthday" name="dog-birthday"> 
            
            <label>Género</label>
            <div class="gender-options">
                <label><input type="radio" name="dog-gender" value="Male"> Macho</label>
                <label><input type="radio" name="dog-gender" value="Female"> Hembra</label>
            </div>

            <h2>Fotos del Perro</h2>
            <div id="image-upload-container">
                <input type="file" id="dog-pictures" name="dog-pictures" multiple accept="image/*" onchange="previewImages(event)">
                <div id="preview-container"></div>
            </div>
            
            <div class="button-group">
                <button type="submit">Guardar Cambios</button>
                <button type="button" onclick="window.history.back()">Cancelar</button>
            </div>
        </form>
    </div>

<script>
function previewImages
(event) {
    const previewContainer = document.getElementById('preview-container');
    previewContainer.innerHTML = ''; 
    
    const files = Array.from(event.target.files);
    files.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const imgContainer = document.createElement('div');
            imgContainer.classList.add('img-preview');
            imgContainer.dataset.index = index;
            
            const img = document.createElement('img');
            img.src = e.target.result;
            img.alt = "Foto del perro";
            
            const removeBtn = document.createElement('button');
            removeBtn.textContent = 'X';
            removeBtn.classList.add('remove-btn');
            removeBtn.onclick = function() {
                imgContainer.remove();
            };
            
            // Hacer que la imagen se agrande al hacer clic
            img.onclick = function() {
                if (img.classList.contains('large')) {
                    img.classList.remove('large');
                } else {
                    img.classList.add('large');
                }
            };
            
            imgContainer.appendChild(img);
            imgContainer.appendChild(removeBtn);
            previewContainer.appendChild(imgContainer);
        };
        reader.readAsDataURL(file);
    });
    
    event.target.value = ""; // Resetea el input para evitar duplicados
}
</script>

<style>
#preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 10px;
}

.img-preview {
    position: relative;
    display: inline-block;
}

.img-preview img {
    width: 100px;
    height: 100px;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer;
}

.remove-btn {
    position: absolute;
    top: 5px;
    right: 5px;
    background-color: red;
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    font-size: 12px;
    width: 20px;
    height: 20px;
}

.img-preview img.large {
    width: 300px;
    height: 300px;
    object-fit: contain;
    transition: all 0.3s ease;
}
</style>

</body>
</html>


