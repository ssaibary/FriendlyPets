<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<title>FriendlyPets</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />

<!-- Google Font -->
<link rel="preconnect" href="https://fonts.gstatic.com" />
<link
	href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400&family=Roboto:wght@400;500;700&display=swap"
	rel="stylesheet" />

<!-- Font Awesome -->
<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
	rel="stylesheet" />

<!-- Libraries Stylesheet -->
<link href="../lib/owlcarousel/assets/owl.carousel.min.css"
	rel="stylesheet" />
<link href="../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css"
	rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link rel="stylesheet" href="../css/style.css" />
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

</head>

<body>
	<!-- Navbar Start -->
	<div class="container-fluid p-0 nav-bar">
    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="nav-item dropdown">
            <a href="?Match/show" class="nav-link user-icon" id="userDropdown">
                <i class="fas fa-user-circle"></i>
            </a>
        </div>
    <?php else: ?>
        <div class="nav-item dropdown">
            <a href="#" class="nav-link user-icon" id="userDropdown"
               role="button" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">
                <i class="fas fa-user-circle"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="?Login/show">Iniciar sesión</a>
                <a class="dropdown-item" href="?Register/show"><strong>Registrarse</strong></a>
            </div>
        </div>
    <?php endif; ?>
	</div>

	<!-- Page Header Start -->
	<div id="header"
		class="container-fluid page-header mb-5 position-relative overlay-bottom">
		<div
			class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5"
			style="min-height: 500px">
			<h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">
				Welcome to our page</h1>
		</div>
	</div>
	<!-- Page Header End -->

	<!-- About Start -->
	<div class="container-fluid py-5">
		<div class="container">
			<div class="section-title">
				<h4 class="text-primary text-uppercase" style="letter-spacing: 5px">
					Welcome to FriendlyPets</h4>
				<h1 class="display-4">Find the Perfect Match for Your Pet</h1>
			</div>
			<div class="row">
				<div class="col-lg-4 py-0 py-lg-5">
					<h1 class="mb-3">Our Story</h1>
					<h5 class="mb-3">Connecting pets and their owners in a fun and safe
						way.</h5>
					<p>FriendlyPets was created to help pet lovers find playmates,
						companions, or even love for their furry friends. Whether you're
						looking for a walking buddy for your dog or a new best friend,
						we're here to make those connections happen.</p>
					<a href="#about"
						class="btn btn-secondary font-weight-bold py-2 px-4 mt-2">Learn
						More</a>
				</div>
				<div class="col-lg-4 py-5 py-lg-0" style="min-height: 500px">
					<div class="position-relative h-100">
						<img class="position-absolute w-100 h-100"
							src="../img/dog-friend.png" style="object-fit: cover"
							alt="FriendlyPets" width="100" />
					</div>
				</div>
				<div class="col-lg-4 py-0 py-lg-5">
					<h1 class="mb-3">Why Choose FriendlyPets?</h1>
					<p>We provide a fun and easy platform for pet lovers to connect,
						interact, and build relationships for their pets. Here's what
						makes us special:</p>
					<h5 class="mb-3">
						<i class="fa fa-paw text-primary mr-3"></i>Safe and verified
						profiles
					</h5>
					<h5 class="mb-3">
						<i class="fa fa-paw text-primary mr-3"></i>Easy-to-use matching
						system
					</h5>
					<h5 class="mb-3">
						<i class="fa fa-paw text-primary mr-3"></i>Chat with other pet
						owners
					</h5>
					<a href="#signup"
						class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Get
						Started</a>
				</div>
			</div>
		</div>
	</div>
	<!-- About End -->

	<!-- Service Start -->
	<div id="service" class="container-fluid pt-5">
		<div class="container">
			<div class="section-title">
				<h4 class="text-primary text-uppercase" style="letter-spacing: 5px">
					Our Services</h4>
				<h1 class="display-4">Explore What FriendlyPets Offers</h1>
			</div>
			<div class="row">
				<div class="col-lg-6 mb-5">
					<div class="row align-items-center">
						<div class="col-sm-5">
							<img class="img-fluid mb-3 mb-sm-0" src="../img/dog-match.png"
								alt="Matching Service" />
						</div>
						<div class="col-sm-7">
							<h4>
								<i class="fa fa-heart service-icon"></i>Find the Match
							</h4>
							<p class="m-0">Use our matching system to find compatible
								companions for your pet based on their preferences, location,
								and personality.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-6 mb-5">
					<div class="row align-items-center">
						<div class="col-sm-5">
							<img style="margin-left: 65px" class="img-fluid mb-3 mb-sm-0"
								src="../img/chat.png" width="50%" alt="Chat Service" />
						</div>
						<div class="col-sm-7">
							<h4>
								<i class="fa fa-comments service-icon"></i>Chat with Owners
							</h4>
							<p class="m-0">Connect with other pet owners through our secure
								chat feature to arrange meet-ups or playdates.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-6 mb-5">
					<div class="row align-items-center">
						<div class="col-sm-5">
							<img style="margin-left: 65px" class="img-fluid mb-3 mb-sm-0"
								src="../img/verificaction.webp" width="50%"
								alt="Verification Service" />
						</div>
						<div class="col-sm-7">
							<h4>
								<i class="fa fa-shield-alt service-icon"></i>Profile
								Verification
							</h4>
							<p class="m-0">Enjoy a safe and trusted environment where users
								are verified through photo submissions of themselves and their
								pets.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-6 mb-5">
					<div class="row align-items-center">
						<div class="col-sm-5">
							<img style="margin-left: 65px" class="img-fluid mb-3 mb-sm-0"
								src="../img/feature.png" width="50%" alt="Premium Service" />
						</div>
						<div class="col-sm-7">
							<h4>
								<i class="fa fa-star service-icon"></i>Premium Features
							</h4>
							<p class="m-0">Unlock premium features to view owner profiles and
								access additional functionalities that enhance your experience.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Service End -->

	<!-- Testimonial Start -->
	<div class="container-fluid py-5">
		<div class="container">
			<div class="section-title">
				<h4 class="text-primary text-uppercase" style="letter-spacing: 5px">
					What Our Users Say</h4>
				<h1 class="display-4">Happy Pets, Happy Owners</h1>
			</div>
			<div class="owl-carousel testimonial-carousel">
				<div class="testimonial-item">
					<div class="d-flex align-items-center mb-3">
						<img class="img-fluid" src="../img/testimonial-1.jpg"
							alt="User Testimonial" />
						<div class="ml-3">
							<h4>Sarah & Bella</h4>
							<i>Dog Owner</i>
						</div>
					</div>
					<p class="m-0">"Thanks to FriendlyPets, Bella found her perfect
						playmate! The platform made it easy to find compatible pets in our
						area, and now they have regular playdates!"</p>
				</div>
				<div class="testimonial-item">
					<div class="d-flex align-items-center mb-3">
						<img class="img-fluid" src="../img/testimonial-2.jpg"
							alt="User Testimonial" />
						<div class="ml-3">
							<h4>John & Max</h4>
							<i>Dog Owner</i>
						</div>
					</div>
					<p class="m-0">"I never thought finding a companion for Max would
						be this easy. The chat feature was perfect for getting to know
						other pet owners before arranging a meeting."</p>
				</div>
				<div class="testimonial-item">
					<div class="d-flex align-items-center mb-3">
						<img class="img-fluid" src="../img/testimonial-3.jpg"
							alt="User Testimonial" />
						<div class="ml-3">
							<h4>Emma & Rocky</h4>
							<i>Dog Owner</i>
						</div>
					</div>
					<p class="m-0">"The profile verification process made me feel
						comfortable using the platform. Rocky made a new friend, and we’re
						both happy with the experience!"</p>
				</div>
				<div class="testimonial-item">
					<div class="d-flex align-items-center mb-3">
						<img class="img-fluid" src="../img/testimonial-4.jpg"
							alt="User Testimonial" />
						<div class="ml-3">
							<h4>Rafa & Rocky</h4>
							<i>Dog Owner</i>
						</div>
					</div>
					<p class="m-0">"Gran aplicación para ampliar mi círculo social. Soy
						un agorafóbico y el hecho de salir poco a poco con mi perro a
						conocer personas, me ha ayudad a pasar mi fobia. Muchas
						felicitaciones al equipo de desarrollo, se nota su increíble
						trabajo y amor por estos amigos caninos nuestros."</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Testimonial End -->

	<!-- Footer Start -->
	<div style="background-color: black"
		class="container-fluid footer text-white mt-5 pt-5 px-0 position-relative overlay-top">
		<div
			class="row mx-0 pt-5 px-sm-3 px-lg-5 mt-4 justify-content-between">
			<div class="col-lg-3 col-md-6 mb-5">
				<h4 class="text-white text-uppercase mb-4"
					style="letter-spacing: 3px">Get In Touch</h4>
				<p class="m-0">
					<i class="fa fa-envelope mr-2"></i>friendlypetshelp@gmail.com
				</p>
			</div>
			<div class="col-lg-3 col-md-6 mb-5">
				<h4 class="text-white text-uppercase mb-4"
					style="letter-spacing: 3px">Follow Us</h4>
				<p>Stay connected with FriendlyPets to get the latest updates, tips,
					and adorable pet moments!</p>
				<div class="d-flex justify-content-start">
					<a class="btn btn-lg btn-outline-light btn-lg-square mr-2"
						href="https://x.com/" target="_blank"><i
						class="fa-brands fa-x-twitter"></i></a> <a
						class="btn btn-lg btn-outline-light btn-lg-square mr-2"
						href="https://www.facebook.com/" target="_blank"><i
						class="fab fa-facebook-f"></i></a> <a
						class="btn btn-lg btn-outline-light btn-lg-square mr-2"
						href="https://es.linkedin.com/" target="_blank"><i
						class="fab fa-linkedin-in"></i></a> <a
						class="btn btn-lg btn-outline-light btn-lg-square"
						href="https://www.instagram.com/" target="_blank"><i
						class="fab fa-instagram"></i></a>
				</div>
			</div>
		</div>
		<div
			class="container-fluid text-center text-white border-top mt-4 py-4 px-sm-3 px-md-5"
			style="border-color: rgba(256, 256, 256, 0.1) !important">
			<p class="mb-2 text-white">
				Copyright &copy; <a class="font-weight-bold" href="#">FriendlyPets</a>.
				All Rights Reserved.
			</p>
			<p class="m-0 text-white">
				Designed with love by <a><strong>Sohaib Saibary</strong></a>
			</p>
		</div>
	</div>
	<!-- Footer End -->

	<!-- Back to Top -->
	<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i
		class="fa fa-angle-double-up"></i></a>

	<!-- JavaScript Libraries -->
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script
		src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
	<script src="../lib/easing/easing.min.js"></script>
	<script src="../lib/waypoints/waypoints.min.js"></script>
	<script src="../lib/owlcarousel/owl.carousel.min.js"></script>
	<script src="../lib/tempusdominus/js/moment.min.js"></script>
	<script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
	<script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

	<!-- Contact Javascript File -->
	<script src="../mail/jqBootstrapValidation.min.js"></script>
	<script src="../mail/contact.js"></script>

	<!-- Template Javascript -->
	<script src="../js/main.js"></script>
</body>
</html>
