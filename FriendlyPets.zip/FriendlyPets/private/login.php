
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/register.css" />
<script defer type="text/javascript" src="../js/register.js"></script>
<title>LogIn</title>
</head>

<body>
	<form method="POST" id="login-form">
		
      <div class="title">
        <a style="color: black;" href="index.php"><strong>X</strong></a>
        <h1>Iniciar Sessión</h1>
      </div>
      <h2>¡Te damos la bienvenida a FriendyPets!</h2>
      
      <?php if (!empty($errors)): ?>
        <div style="color: red; text-align: center;">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
      <?php endif; ?>

		<label for="email"><img src="../media/icons/email.png" alt="icon-email"
			width="15" />Correo</label> <input type="email" id="email"
			name="email"
			value="<?= isset($email) && !isset($errors['email']) ? $email : '' ?>"
			placeholder="<?= isset($errors['email']) ? $errors['email'] : 'Tu Correo' ?>">
		<label for="password"><img src="../media/icons/password.png"
			alt="icon-password" width="15" />Contraseña</label> <input
			type="password" id="password" name="password"
			placeholder="<?= isset($errors['password']) ? $errors['password'] : 'Contraseña' ?>">
		<button type="submit" name="submit">Entrar</button>
		<div class="account">
        <p style="text-align:center;">Not registered yet? <a href="?Register/show">create your account here</a></p>
        <p style="text-align:center;"><a href="?PasswordReset/show">Forgot your password?</a></p>
      </div>
	</form>
</body>
</html>
