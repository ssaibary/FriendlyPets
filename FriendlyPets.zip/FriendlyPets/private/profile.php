<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<title>Perfil - FriendlyPets</title>
<link rel="stylesheet" href="../css/match.css" />
<link rel="stylesheet" href="../css/profile.css" />
</head>
<body>
	<!-- Navbar Start -->
	<div class="container-fluid p-0 nav-bar">
		<nav class="navbar">
			<a href="index.php" class="navbar-brand">FriendlyPets</a>
			<button class="menu-toggle" onclick="toggleMenu()">☰</button>
			<div id="nav" class="navbar-nav">
				<a href="match.php" class="nav-link">Match</a> <a href="chat.php"
					class="nav-link">Chat</a> <a href="profile.php" class="nav-link">Profile</a>
			</div>
		</nav>
	</div>

	<!-- Profile Section -->
	<div class="profile-container">
		<img src="../media/dog.jpg" alt="Foto de perfil" class="profile-img" />
		<h2>Juan Pérez</h2>
		<p class="profile-info">
			<strong>Correo:</strong> juan.perez@example.com
		</p>
		<p class="profile-info">
			<strong>Fecha de Nacimiento:</strong> 15 de mayo de 1990
		</p>
		<p class="profile-info">
			<strong>Género:</strong> Hombre
		</p>

		<h3>Mascota</h3>
		<p class="profile-info">
			<strong>Nombre:</strong> Rex
		</p>
		<p class="profile-info">
			<strong>Fecha de Nacimiento:</strong> 20 de agosto de 2020
		</p>
		<p class="profile-info">
			<strong>Género:</strong> Macho
		</p>

		<h3>Fotos de Rex</h3>
		<div class="pet-photos">
			<img src="../img/dog-example.jpg" alt="Foto de la mascota" /> <img
				src="../img/dog-example2.jpg" alt="Foto de la mascota" /> <img
				src="../img/dog-example3.jpg" alt="Foto de la mascota" />
		</div>

		<a href="profileForm.php">
			<button class="edit-btn">Editar Perfil</button>
		</a>
	</div>
	<script>
      function toggleMenu() {
        const nav = document.getElementById("nav");
        nav.classList.toggle("active");
      }
    </script>
</body>
</html>
