<?php
// <a style="color:white;" href="resetPassword.php">
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/register.css" />
<script defer type="text/javascript" src="../js/register.js"></script>
<title>LogIn</title>
</head>

<body>
	<form method="POST" id="login-form">
		<h1>Recuperar Contraseña</h1>

		<label for="email"><img src="../media/icons/email.png" alt="icon-email"
			width="15" />Correo</label> <input type="email" id="email"
			name="email"
			value="<?= isset($email) ? htmlspecialchars($email) : '' ?>"
			placeholder="<?= isset($errors['email']) ? $errors['email'] : 'Tu Correo' ?>">
		<button type="submit" name="submit">Enviar</button>
		
	</form>
</body>
</html>

