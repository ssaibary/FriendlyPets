<?php
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header("Location: ?Login/show");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/x-icon" href="../media/LOGO-modified.png" />
<link rel="stylesheet" href="../css/match.css" />
<script defer type="text/javascript" src="../js/match.js"></script>
<title>Match Page</title>
</head>
<body>
	<!-- Navbar Start -->
	<div class="container-fluid p-0 nav-bar">
		<nav class="navbar">
			<a href="index.php" class="navbar-brand">FriendlyPets</a>
			<button class="menu-toggle" onclick="toggleMenu()">☰</button>
			<div id="nav" class="navbar-nav">
				<a href="?Match/show" class="nav-link">Match</a> <a
					href="?Chat/show" class="nav-link">Chat</a> <a href="?Profile/show"
					class="nav-link">Profile</a>
			</div>
		</nav>
	</div>

	<!-- Main Content: Profile Card -->
	<div id="app">
		<div class="card" id="profile-card">
			<div class="image-container">
				<img src="" alt="Profile Image" id="profile-image"
					onclick="openProfileModal()" />
				<button class="prev" onclick="changeImage(-1)">&#10094;</button>
				<button class="next" onclick="changeImage(1)">&#10095;</button>
			</div>
			<h2 id="profile-name"></h2>
			<p id="profile-description"></p>
			<div class="actions">
				<button class="button reject" onclick="handleAction(false)"
					id="reject-button">&times;</button>
				<button class="button accept" onclick="handleAction(true)"
					id="accept-button">&#10084;</button>
			</div>
		</div>
	</div>

	<!-- Modal for profile details -->
	<div id="profile-modal" class="modal">
		<div class="modal-content">
			<span class="close" onclick="closeProfileModal()">&times;</span>

			<div class="modal-image-container">
				<button class="modal-nav-button left" onclick="changeModalImage(-1)">&#9664;</button>
				<img id="modal-profile-image" src="" alt="Profile Image" />
				<button class="modal-nav-button right" onclick="changeModalImage(1)">&#9654;</button>
			</div>

			<h2 id="modal-profile-name"></h2>
			<p id="modal-profile-description"></p>
			<p id="modal-profile-age"></p>
		</div>
	</div>



	<script>
        // Cargar perfiles desde PHP como un array de JavaScript
        const profiles = <?php echo json_encode($matches); ?>;
        let currentIndex = 0;
        let imageIndex = 0;

        // Función para actualizar el perfil mostrado
function updateProfile() {
        if (currentIndex >= profiles.length) {
            document.getElementById("app").innerHTML = "<h2>No more profiles!</h2>";
            return;
        }

        const profile = profiles[currentIndex];
        const images = profile.dog_pictures ? JSON.parse(profile.dog_pictures) : [];

        // Mostrar la primera imagen si hay imágenes disponibles
        imageIndex = 0;
        document.getElementById("profile-image").src = images.length > 0 ? images[imageIndex] : "default.jpg";
        
        // Mostrar nombre y descripción
        document.getElementById("profile-name").textContent = `${profile.dog_name}, ${profile.dog_birthday}`;
        document.getElementById("profile-description").textContent = profile.dog_description || "No description available.";
    }
        
    function changeImage(direction) {
        const profile = profiles[currentIndex];
        const images = profile.dog_pictures ? JSON.parse(profile.dog_pictures) : [];

        if (images.length > 1) {
            imageIndex = (imageIndex + direction + images.length) % images.length;
            document.getElementById("profile-image").src = images[imageIndex];
        }
    }

        // Función para manejar las acciones (aceptar o rechazar)
function handleAction(isMatch) {
    const profile = profiles[currentIndex];
    if (!profile || !profile.id) return;

    fetch("?Match/form", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `matched_user_id=${profile.id}&is_like=${isMatch ? 1 : 0}`
    })
    .then(response => {
    	response.text()
    }) // Obtener el texto de la respuesta primero
    .then(text => {
        try {
        	console.log(text);
            return JSON.parse(text); // Intentar convertirlo a JSON
        } catch (error) {
            console.error("Error de JSON:", error);
            throw new Error("La respuesta no es JSON válido");
        }
    })
    .then(data => {
        if (data.success) {
            if (data.match) {
                alert("¡Es un Match! Ahora puedes chatear.");
            }
        } else {
            console.error("Error:", data.error);
        }
    })
    .catch(error => console.error("Fetch error:", error));

    nextProfileAnimation(isMatch);
}

function nextProfileAnimation(isMatch) {
    const card = document.getElementById("profile-card");
    if (!card) return;

    // Aplicar animación de deslizamiento según la elección
    card.style.transition = "transform 0.5s ease-out, opacity 0.5s ease-out";
    card.style.transform = isMatch ? "translateX(100px) rotate(20deg)" : "translateX(-100px) rotate(-20deg)";
    card.style.opacity = "0";

    setTimeout(() => {
        currentIndex++;
        if (currentIndex < profiles.length) {
            updateProfile();
            card.style.transition = "none";
            card.style.transform = "translateX(0) rotate(0)";
            card.style.opacity = "1";
            void card.offsetWidth; // Forzar reflujo para resetear la animación
            card.style.transition = "transform 0.5s ease-out, opacity 0.5s ease-out";
        } else {
            document.getElementById("app").innerHTML = "<h2>No more profiles!</h2>";
        }
    }, 500);
}


let modalImageIndex = 0; // Índice para controlar la imagen actual en el modal

function openProfileModal() {
    const profile = profiles[currentIndex];
    const images = profile.dog_pictures ? JSON.parse(profile.dog_pictures) : [];

    const modal = document.getElementById("profile-modal");
    const modalImage = document.getElementById("modal-profile-image");
    const modalName = document.getElementById("modal-profile-name");
    const modalDescription = document.getElementById("modal-profile-description");
    const modalAge = document.getElementById("modal-profile-age");

    modal.style.display = "block";
    modalName.textContent = `${profile.dog_name}, ${profile.dog_birthday}`;
    modalDescription.textContent = profile.dog_description || "No description available.";
    modalAge.textContent = `Age: ${profile.dog_birthday}`;

    if (images.length > 0) {
        modalImage.src = images[modalImageIndex];
    } else {
        modalImage.src = ""; // Si no hay imágenes, dejar vacío
    }

    // Guardar imágenes en el modal para cambiar con botones
    modalImage.dataset.images = JSON.stringify(images);
    modalImageIndex = 0; // Reiniciar índice
}

function changeModalImage(direction) {
    const modalImage = document.getElementById("modal-profile-image");
    const images = JSON.parse(modalImage.dataset.images || "[]");

    if (images.length === 0) return;

    modalImageIndex += direction;
    if (modalImageIndex < 0) modalImageIndex = images.length - 1;
    if (modalImageIndex >= images.length) modalImageIndex = 0;

    modalImage.src = images[modalImageIndex];
}




        // Función para cerrar el modal
        function closeProfileModal() {
            const modal = document.getElementById("profile-modal");
            modal.style.display = "none";
        }

        // Cerrar modal si se hace clic fuera de él
        window.onclick = function (event) {
            const modal = document.getElementById("profile-modal");
            if (event.target === modal) {
                closeProfileModal();
            }
        };

        // Función para alternar el menú
        function toggleMenu() {
            const nav = document.getElementById("nav");
            nav.classList.toggle("active");
        }

        // Inicializar el primer perfil
        updateProfile();
    </script>
</body>
</html>

