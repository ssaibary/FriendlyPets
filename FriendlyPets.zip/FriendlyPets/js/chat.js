/*function openChat(name) {
  document.getElementById("placeholder-text").style.display = "none";
  document.getElementById("messages").style.display = "flex";
  document.getElementById("inputBox").style.display = "flex";
  document.getElementById(
    "messages"
  ).innerHTML = `<div class='message received'>¡Hola! Soy ${name} 🐶</div>`;
}

function sendMessage() {
  const input = document.getElementById("messageInput");
  const message = input.value;
  if (message.trim() !== "") {
    const messageContainer = document.getElementById("messages");
    const newMessage = document.createElement("div");
    newMessage.classList.add("message", "sent");
    newMessage.textContent = message;
    messageContainer.appendChild(newMessage);
    input.value = "";
    messageContainer.scrollTop = messageContainer.scrollHeight;
  }
}

function toggleMenu() {
  const nav = document.getElementById("nav");
  nav.classList.toggle("active");
}
*/

/*document.addEventListener("DOMContentLoaded", function () {
    loadMatches();
});

function loadMatches() {

    fetch("?Chat/show")
	
        .then(response => {
			console.log(response);
			return response.json();
		})

        .then(matches => {
			console.log("Hola")
            let list = document.querySelector(".chat-list ul");
            list.innerHTML = "";
            matches.forEach(match => {
				console.log(match.dog_name);
                let li = document.createElement("li");
                li.textContent = `🐶 ${match.dog_name}`;
				
                li.onclick = () => openChat(match.id, match.dog_name);
                list.appendChild(li);
            });
        });
}
*/

function openChat(userId, userName) {
    document.getElementById("placeholder-text").style.display = "none";
    let messagesContainer = document.getElementById("messages");
    messagesContainer.innerHTML = "";
    messagesContainer.style.display = "block";
    document.getElementById("inputBox").style.display = "block";
	
	console.log(userName);

    fetch(`?Chat/getMessages/${userId}`)
        .then(response => response.json())
        .then(messages => {
            console.log("Mensajes recibidos:", messages); 


			messages.forEach(msg => {
			    let msgWrapper = document.createElement("div"); // Contenedor del mensaje
			    let msgElement = document.createElement("p"); // Texto del mensaje

			    msgElement.textContent = msg.sender_id == currentUserId 
			        ? `${msg.message}` 
			        : `${msg.message}`;

			    msgWrapper.classList.add("message-wrapper"); // Contenedor flexible

			    if (msg.sender_id == currentUserId) {
			        msgWrapper.classList.add("sent"); // Mensaje propio
			    } else {
			        msgWrapper.classList.add("received"); // Mensaje del otro usuario
			    }

			    msgWrapper.appendChild(msgElement);
			    messagesContainer.appendChild(msgWrapper);
			});
        })
        .catch(error => console.error("Error cargando mensajes:", error));
    
    document.getElementById("messageInput").dataset.receiverId = userId;
}


function sendMessage() {
    let messageInput = document.getElementById("messageInput");

    let receiverId = messageInput.dataset.receiverId;
    let message = messageInput.value.trim();
	console.log(message);

	console.log(currentUserId);
	console.log(receiverId);
	
    if (message !== "") {
        fetch("?Chat/form", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
			body: `sender_id=${currentUserId}&receiver_id=${receiverId}&message=${message}`
            /*body: JSON.stringify({ sender_id: currentUserId, receiver_id: receiverId, message })*/
        })
        .then(() => {
            let messagesContainer = document.getElementById("messages");
            let msgElement = document.createElement("p");
            msgElement.textContent = `Tú: ${message}`;
            messagesContainer.appendChild(msgElement);
            messageInput.value = "";
        });
    }
}
















