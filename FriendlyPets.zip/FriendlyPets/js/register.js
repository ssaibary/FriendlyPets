const steps = document.querySelectorAll(".form-step");
const nextBtns = document.querySelectorAll(".next-btn");
const prevBtns = document.querySelectorAll(".prev-btn");


let currentStep = 0;

nextBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    if (currentStep < steps.length - 1) {
      steps[currentStep].classList.remove("active");
      currentStep++;
      steps[currentStep].classList.add("active");
    }
  });
});

prevBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    if (currentStep > 0) {
      steps[currentStep].classList.remove("active");
      currentStep--;
      steps[currentStep].classList.add("active");
    }
  });
});

/*
const fileInput = document.getElementById("dog-pictures");
const previewContainer = document.getElementById("preview-container");

fileInput.addEventListener("change", (event) => {
  // Limpiar el contenedor de vistas previas
  previewContainer.innerHTML = "";

  // Iterar por cada archivo seleccionado
  Array.from(event.target.files).forEach((file, index) => {
    if (file.type.startsWith("image/")) {
      const reader = new FileReader();

      // Crear un contenedor para cada imagen
      const imageWrapper = document.createElement("div");
      imageWrapper.classList.add("image-preview");

      // Crear el botón para eliminar la imagen
      const removeButton = document.createElement("button");
      removeButton.classList.add("remove-image");
      removeButton.textContent = "X";
      removeButton.addEventListener("click", () => {
        imageWrapper.remove();
        // Remover el archivo del input de archivos
        const dataTransfer = new DataTransfer();
        Array.from(fileInput.files).forEach((f, i) => {
          if (i !== index) dataTransfer.items.add(f);
        });
        fileInput.files = dataTransfer.files;
      });

      // Cuando se cargue la imagen, mostrarla
      reader.onload = () => {
        const img = document.createElement("img");
        img.src = reader.result;
        imageWrapper.appendChild(img);
        imageWrapper.appendChild(removeButton);
        previewContainer.appendChild(imageWrapper);
      };

      reader.readAsDataURL(file);
    }
  });
});*/

const fileInput = document.getElementById("dog-pictures");
const previewContainer = document.getElementById("preview-container");
const uploadArea = document.getElementById("upload-area");

uploadArea.addEventListener("click", () => {
  fileInput.click(); // Simula un clic en el input de archivo cuando el área es clickeada
});

fileInput.addEventListener("change", (event) => {
  // Añadir los nuevos archivos al array sin borrar los anteriores
  Array.from(event.target.files).forEach((file) => {
    if (file.type.startsWith("image/")) {
      const reader = new FileReader();

      // Crear contenedor para la imagen
      const imageWrapper = document.createElement("div");
      imageWrapper.classList.add("image-preview");

      // Crear botón de eliminar
      const removeButton = document.createElement("button");
      removeButton.classList.add("remove-image");
      removeButton.textContent = "X";
      removeButton.addEventListener("click", () => {
        // Remover la imagen del preview
        imageWrapper.remove();
      });

      reader.onload = () => {
        const img = document.createElement("img");
        img.src = reader.result;
        imageWrapper.appendChild(img);
        imageWrapper.appendChild(removeButton);
        previewContainer.appendChild(imageWrapper);
      };

      reader.readAsDataURL(file);
    }
  });
});



document.addEventListener("DOMContentLoaded", function () {
    const toggleIcons = document.querySelectorAll(".password-toggle-icon i");

    toggleIcons.forEach(icon => {
        icon.addEventListener("click", function () {
            // Buscar el campo de entrada dentro del contenedor padre
            let inputField = this.closest(".password-container").querySelector("input");

            if (inputField.type === "password") {
                inputField.type = "text";  // Mostrar contraseña
                this.classList.remove("fa-eye");
                this.classList.add("fa-eye-slash"); // Cambiar icono a "ojo tachado"
            } else {
                inputField.type = "password"; // Ocultar contraseña
                this.classList.remove("fa-eye-slash");
                this.classList.add("fa-eye"); // Volver al icono normal
            }
        });
    });
});

