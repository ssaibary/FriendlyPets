
let currentIndex = 0;

function updateProfile() {
	const profile = profiles[currentIndex];
	const card = document.getElementById("profile-card");

	card.style.opacity = "1";
	card.style.transform = "translateX(0) rotate(0deg)";

	document.getElementById("profile-image").src = profile.image;
	document.getElementById(
		"profile-name"
	).textContent = `${profile.name}, ${profile.age}`;
	document.getElementById("profile-description").textContent =
		profile.description;
}

function handleAction(isMatch) {
	const card = document.getElementById("profile-card");

	if (isMatch) {
		card.style.transform = "translateX(100px) rotate(20deg)";
	} else {
		card.style.transform = "translateX(-100px) rotate(-20deg)";
	}

	card.style.opacity = "0";

	setTimeout(() => {
		currentIndex++;
		if (currentIndex < profiles.length) {
			updateProfile();
		} else {
			document.getElementById("app").innerHTML = "<h2>No more profiles!</h2>";
		}
	}, 500);
}

function openProfileModal() {
	const profile = profiles[currentIndex];

	const modal = document.getElementById("profile-modal");
	const modalImage = document.getElementById("modal-profile-image");
	const modalName = document.getElementById("modal-profile-name");
	const modalDescription = document.getElementById("modal-profile-description");
	const modalAge = document.getElementById("modal-profile-age");

	modal.style.display = "block";
	modalImage.src = profile.image;
	modalName.textContent = `${profile.name}, ${profile.age}`;
	modalDescription.textContent = profile.description;
	modalAge.textContent = `Age: ${profile.age}`;
}

function closeProfileModal() {
	const modal = document.getElementById("profile-modal");
	modal.style.display = "none";
}

window.onclick = function(event) {
	const modal = document.getElementById("profile-modal");
	if (event.target === modal) {
		closeProfileModal();
	}
};

function toggleMenu() {
	const nav = document.getElementById("nav");
	nav.classList.toggle("active");
}

updateProfile();
