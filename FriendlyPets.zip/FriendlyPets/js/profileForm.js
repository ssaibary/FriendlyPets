const fileInput = document.getElementById('dog-pictures');
const previewContainer = document.getElementById('preview-container');

fileInput.addEventListener('change', () => {
    previewContainer.innerHTML = '';
    const files = fileInput.files;
    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = document.createElement('img');
            img.src = e.target.result;
            previewContainer.appendChild(img);
        };
        reader.readAsDataURL(file);
    });
});