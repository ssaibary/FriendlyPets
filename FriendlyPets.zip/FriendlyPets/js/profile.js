document.addEventListener("DOMContentLoaded", function () {
    const profileForm = document.getElementById("profile-form");

    profileForm.addEventListener("submit", function (event) {
        event.preventDefault();
        
        const formData = new FormData(profileForm);
        
        // Simulación de actualización de perfil
        console.log("Datos actualizados:", Object.fromEntries(formData));
        alert("Perfil actualizado con éxito!");
    });

    // Simulación de carga de datos existentes
    function loadProfileData() {
        document.getElementById("name").value = "Juan Pérez";
        document.getElementById("email").value = "juan.perez@example.com";
        document.getElementById("birthday").value = "1990-05-15";
        document.getElementById("dog-name").value = "Rex";
        document.getElementById("dog-birthday").value = "2020-08-20";
        document.getElementById("male").checked = true;
        document.getElementById("dog-male").checked = true;
    }

    loadProfileData();
});
