<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

define("__ROOT__", __DIR__ . "/../");

function my_autoload($classe) {
    $carpetes = array(
        ".",
        "core",
        "controller",
        "model",
        "view"
    );
    
    foreach ($carpetes as $carpeta) {
        if (file_exists(__ROOT__ . "classes/$carpeta/$classe.php")) {
            include __ROOT__ . "classes/$carpeta/$classe.php";
            return;
        }
    }
}

try {
    spl_autoload_register("my_autoload");
    
    FrontController::dispatch();
} catch (Exception $e) {
    echo $e->getMessage();
}

?>
